/** Automatically generated file. DO NOT MODIFY */
package edu.hrbeu.ContentResolverDemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}